#!/usr/bin/python
alsncaskncsnac
a.scnaksnckascn
.qckqbckqcbkqc
.csb.sbcksqcbksjc
,cbn	asmcbas,c
