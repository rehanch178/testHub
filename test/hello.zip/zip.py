def lambda_handler(event, context):
    x = 'rehan'
    print (x)
    return 'Successful'
